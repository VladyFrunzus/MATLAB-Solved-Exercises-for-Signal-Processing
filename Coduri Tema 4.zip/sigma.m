function functie = sigma(t, amplitudine)
if t > 0
    functie = amplitudine;
else 
    functie = 0;
end
end