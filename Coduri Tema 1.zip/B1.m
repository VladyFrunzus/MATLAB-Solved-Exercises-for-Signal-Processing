clear
M = round(10*rand(10,10))
Maria_Maria1(M)
function S = Maria_Maria1(M1)
S = M1(1,1) + M1(10,10) + M1(1,10) + M1(10,1);
end